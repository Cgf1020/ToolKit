#ifndef EPOLLER_H
#define EPOLLER_H

#include <stdint.h>
#include <vector>
#include <sys/epoll.h>



//https://blog.csdn.net/weixin_28673511/article/details/130114682  epoll 代码学习

class Epoller
{
public:
    Epoller();



public:
    /*添加监听的文件描述符，往epoll的红黑树上
    */
    bool AddFd(int fd, uint32_t events);

    bool ModFd(int fd, uint32_t events);

    bool DelFd(int fd);

    /*阻塞等待监听的socket是否有事件
     * 可以通过设置超时时间timeout来控制监听的行为为阻塞模式还是超时模式
    */
    int Wait(int timeoutMs = -1);

    int GetEventFd(size_t i) const;

    uint32_t GetEvents(size_t i) const;

private:
    int epollFd_{-1};   //epoll的文件描述符

    std::vector<struct epoll_event> events_{1024};
};

#endif // EPOLLER_H
