#ifndef WEBSERVER_H
#define WEBSERVER_H

#include "epoller.h"
#include "../http/httpconn.h"
#include "../pool/ThreadPool.h"
#include <memory>
#include <map>

class WebServer
{
public:
    WebServer();
    ~WebServer();

    void Start();

private:
    bool InitSocket_();     //初始化网络连接

    void InitEventMode_(int trigMode);

    void DealListen_();
    void DealRead_(HttpConn* client);

    void OnRead_(HttpConn* client);



    void CloseConn_(HttpConn* client);


    static int SetFdNonblock(int fd);


private:
    std::unique_ptr<Epoller> epoller_;
    std::unique_ptr<ThreadPool> threadpool_;


private:
    int port_{9000};        //web服务器的http端口
    int listenFd_{0};       //创建套接字返回文件描述符

    bool openLinger_{true}; //不知道干什么用的
    int timeoutMS_;         //ms 设置超时

    uint32_t listenEvent_;  //监听事件
    uint32_t connEvent_;    //连接事件

    bool isClose_{false};

    std::unordered_map<int, HttpConn> users_;
};

#endif // WEBSERVER_H
