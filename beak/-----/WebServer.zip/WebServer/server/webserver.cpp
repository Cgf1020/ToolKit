#include "webserver.h"

#include <iostream>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <assert.h> // close()
#include <fcntl.h>  // fcntl()


WebServer::WebServer()
{
    epoller_ = std::make_unique<Epoller>();

    threadpool_ = std::make_unique<ThreadPool>();

    InitEventMode_(3);

    if(!InitSocket_()) {
        isClose_ = true;

        std::cout << "InitSocket_ failed!" << std::endl;
    }
}

WebServer::~WebServer()
{
    close(listenFd_);
    isClose_ = true;
}

bool WebServer::InitSocket_()
{
    int ret = 0;
    struct sockaddr_in addr;

    if(port_ > 65535 || port_ < 1024) {
        std::cout << "Port:" << port_ << " error" << std::endl;
        return false;
    }

    //1. 为服务器创建socket对象
    listenFd_ = socket(AF_INET, SOCK_STREAM, 0);//AF_INET决定了要用ipv4地址（32位的）与端口号（16位的）的组合
                                                //对于TCP协议，type参数指定为SOCK_STREAM，面向流的传输协议。
                                                //protocol 为指定协议参数，一般使用TCP，设为0就行，IPPROTO_TCP
    if(listenFd_ < 0) {
        std::cout << "Create socket error!" << port_ << std::endl;
        return false;
    }

    //2.setsockopt：设置一些套接字的配置
    {
        int optval = 1;
        /* 端口复用 */
        /* 只有最后一个套接字会正常接收数据。 */
        ret = setsockopt(listenFd_, SOL_SOCKET, SO_REUSEADDR, (const void*)&optval, sizeof(int));
        if(ret == -1) {
            std::cout << "set socket setsockopt error !" << std::endl;
            close(listenFd_);
            return false;
        }
    }

    {
        struct linger optLinger = { 0 };
        if(openLinger_) {
            /* 优雅关闭: 直到所剩数据发送完毕或超时 */
            optLinger.l_onoff = 1;
            optLinger.l_linger = 1;
        }
        ret = setsockopt(listenFd_, SOL_SOCKET, SO_LINGER, &optLinger, sizeof(optLinger));
        if(ret < 0) {
            close(listenFd_);
            std::cout << "Init linger error!" << std::endl;
            return false;
        }
    }

    //3.bind地址
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    addr.sin_port = htons(port_);
    ret = bind(listenFd_, (struct sockaddr *)&addr, sizeof(addr));	//绑定地址(网络地址，端口号) 绑定这个套节字到一个本地地址
    if(ret < 0) {
        std::cout << "Bind Port error!" << std::endl;
        close(listenFd_);
        return false;
    }

    //4. listen 监听（看那个客户端发起连接）
    ret = listen(listenFd_, 20);        //同时最多有20个客户端连接
    if(ret < 0) {
        std::cout << "Listen port error!" << std::endl;
        close(listenFd_);
        return false;
    }


    //5.epoll
    ret = epoller_->AddFd(listenFd_, listenEvent_ | EPOLLIN);
    if(ret == 0) {
        std::cout << "Add listen error!" << std::endl;
        close(listenFd_);
        return false;
    }

    SetFdNonblock(listenFd_);
    std::cout << "Server port" << std::endl;

    return true;
}

void WebServer::InitEventMode_(int trigMode)
{
    //https://blog.csdn.net/qq_41413211/article/details/129310969
    /*
     * EPOLLRDHUP：表示对端已经关闭连接，或者关闭了写操作端的写入
     * EPOLLONESHOT：表示将事件设置为一次性事件
     * EPOLLET：表示将epoll设置为边缘触发模式
    */
    listenEvent_ = EPOLLRDHUP;  //
    connEvent_ = EPOLLONESHOT | EPOLLRDHUP;
    switch (trigMode)
    {
    case 0:
        break;
    case 1:
        connEvent_ |= EPOLLET;
        break;
    case 2:
        listenEvent_ |= EPOLLET;
        break;
    case 3:
        listenEvent_ |= EPOLLET;
        connEvent_ |= EPOLLET;
        break;
    default:
        listenEvent_ |= EPOLLET;
        connEvent_ |= EPOLLET;
        break;
    }
//    HttpConn::isET = (connEvent_ & EPOLLET);
}

void WebServer::DealListen_()
{
    struct sockaddr_in addr;
    socklen_t len = sizeof(addr);

    //等待连接 三次握手
    int fd = accept(listenFd_, (struct sockaddr *)&addr, &len);

    if(fd <= 0)
    {
        std::cout << "DealListen_ accept failed !" << std::endl;
        return;
    }

    std::cout << "DealListen_ accept succend ! fd = " << fd << std::endl;

    users_[fd].init(fd, addr);

    epoller_->AddFd(fd, EPOLLIN | connEvent_);
    SetFdNonblock(fd);
}

void WebServer::DealRead_(HttpConn *client)
{
    assert(client);
    threadpool_->AddTask(std::bind(&WebServer::OnRead_, this, client));
}

void WebServer::OnRead_(HttpConn *client)
{
    //从socket fd中读取数据
    int ret = -1;
    int readErrno = 0;
    ret = client->read(&readErrno);

    if(ret <= 0 && readErrno != EAGAIN) {
        CloseConn_(client);
        return;
    }

    client->process();
}

void WebServer::CloseConn_(HttpConn *client)
{
    assert(client);
    std::cout << "Client quit! fd = " << client->GetFd() << std::endl;
    epoller_->DelFd(client->GetFd());
    client->Close();
}

int WebServer::SetFdNonblock(int fd)
{
    assert(fd > 0);
    return fcntl(fd, F_SETFL, fcntl(fd, F_GETFD, 0) | O_NONBLOCK);
}

void WebServer::Start()
{
    int timeMS = -1;  /* epoll wait timeout == -1 无事件将阻塞 */

    std::cout << " ========== Server start ==========" << std::endl;
    while(!isClose_) {
        int eventCnt = epoller_->Wait(timeMS);  //返回的是就绪队列中对的文件描述符的数量

        for(int i = 0; i < eventCnt; i++)
        {
            /* 处理事件 */
            //1.获取文件描述符,是那个socket有事件到来
            int fd = epoller_->GetEventFd(i);

            //2.根据文件描述符获取事件的类型
            uint32_t events = epoller_->GetEvents(i);


            if(fd == listenFd_)
            {
                // 有链接到来
                std::cout << "有链接来了 !" << std::endl;
                DealListen_();
            }
            else
            {
                if(events & (EPOLLRDHUP | EPOLLHUP | EPOLLERR)) //客户端关闭连接
                {
                    std::cout << "fd qiut !" << std::endl;
                    CloseConn_(&users_[fd]);
                }
                else if(events & EPOLLIN)       //有数据可读
                {
                    std::cout << "fd read = " << fd << std::endl;
                    DealRead_(&users_[fd]);
                }
                else if(events & EPOLLOUT)      //有数据可写
                {
                    std::cout << "fd write" << std::endl;
                }
            }
        }
    }
}































