#ifndef BUFFER_H
#define BUFFER_H

#include <vector>
#include <atomic>
#include <unistd.h>  // write
#include <sys/uio.h> //readv

class Buffer
{
public:
    Buffer(int initBuffSize = 1024);

    /*
     * 重置buffer
    */
    void RetrieveAll();

    /*
     * 读取socket 的数据
    */
    ssize_t ReadFd(int fd, int* Errno);


private:
    std::vector<char> buffer_;      //读取的buffer空间

    std::atomic<std::size_t> readPos_;  //读取的位置

    std::atomic<std::size_t> writePos_; //写的位置
};

#endif // BUFFER_H
