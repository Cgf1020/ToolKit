#include "buffer.h"

Buffer::Buffer(int initBuffSize)
    :buffer_(initBuffSize)
{

}

void Buffer::RetrieveAll()
{
    //将数组清零
//    bzero(&buffer_[0], buffer_.size());

    readPos_ = 0;
    writePos_ = 0;
}

ssize_t Buffer::ReadFd(int fd, int *Errno)
{
    char buff[65535];
    struct iovec iov[2];
}
