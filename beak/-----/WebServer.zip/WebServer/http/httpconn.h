#ifndef HTTPCONN_H
#define HTTPCONN_H

/*将每个socket 封装成一个 http对象*/

#include <stdlib.h>      // atoi()
#include <errno.h>
#include <sys/types.h>
#include <sys/uio.h>     // readv/writev
#include <arpa/inet.h>   // sockaddr_in
#include <unistd.h>
#include <atomic>


#include "httprequest.h"

class HttpConn
{
public:
    HttpConn();
    ~HttpConn();

    void init(int fd, const sockaddr_in& addr);

    void Close();

    int GetFd() const noexcept{
        return fd_;
    }

    ssize_t read(int* saveErrno);

    bool process();

public:

    static std::atomic<int> userCount;


private:
    HttpRequest request_;


private:
    int fd_{-1};        //与客户端连接的socket fd

    bool isClose_{true};  //连接是否关闭

    struct sockaddr_in addr_;

    char buffer[2048];

    ssize_t m_read_idx{0};

};

#endif // HTTPCONN_H
