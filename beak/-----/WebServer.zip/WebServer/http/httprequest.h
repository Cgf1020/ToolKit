#ifndef HTTPREQUEST_H
#define HTTPREQUEST_H

#include <string>
#include <unordered_map>



class HttpRequest
{
    //解析htp请求的状态
    enum PARSE_STATE
    {
        REQUEST_LINE,   //request line 请求行
        HEADERS,        //解析headers
        BODY,           //解析body体
        FINISH,         //完成解析
    };

    //Http的code
    enum HTTP_CODE
    {
        NO_REQUEST = 0,
        GET_REQUEST,
        BAD_REQUEST,
        NO_RESOURSE,
        FORBIDDENT_REQUEST,
        FILE_REQUEST,
        INTERNAL_ERROR,
        CLOSED_CONNECTION,
    };

public:
    HttpRequest();

    /* 恢复初始化的状态，初始化变量
    */
    void Init();

    /*解析http请求
     * @buffer: http请求的数据
    */
    bool parse(char* buffer, ssize_t read_idx);


private:
    bool parseLine();

    char *get_line() { return buffer_ + m_start_line; }

private:
    ssize_t m_checked_idx{0};
    ssize_t m_read_idx{0};
    ssize_t m_start_line{0};

    char* buffer_{NULL};

    PARSE_STATE state_;

    std::string method_, path_, version_, body_;

    std::unordered_map<std::string, std::string> header_;
    std::unordered_map<std::string, std::string> post_;
};

#endif // HTTPREQUEST_H
