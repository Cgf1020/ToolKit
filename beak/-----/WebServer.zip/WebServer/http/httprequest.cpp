#include "httprequest.h"

#include <iostream>

HttpRequest::HttpRequest()
{
    Init();
}

void HttpRequest::Init()
{
    m_checked_idx = 0;
    method_ = path_ = version_ = body_ = "";
    state_ = REQUEST_LINE;
    header_.clear();
    post_.clear();
}

bool HttpRequest::parse(char *buffer, ssize_t read_idx)
{
    buffer_ = buffer;
    m_read_idx = read_idx;

//    const char CRLF[] = "\r\n";

    parseLine();

    char* text = get_line();
    m_start_line = m_checked_idx;


    std::cout << "parse = " << text << std::endl;

    while(state_ != FINISH)
    {
        switch(state_)
        {
        case REQUEST_LINE:
//            if(!ParseRequestLine_(line)) {
//                return false;
//            }
//            ParsePath_();
            break;
        case HEADERS:
//            ParseHeader_(line);
//            if(buff.ReadableBytes() <= 2) {
//                state_ = FINISH;
//            }
            break;
        case BODY:
//            ParseBody_(line);
            break;
        default:
            break;
        }


    }
}

bool HttpRequest::parseLine()
{
    char temp;
    for (; m_checked_idx < m_read_idx; ++m_checked_idx)
    {
        temp = buffer_[m_checked_idx];
        if (temp == '\r')
        {
            if ((m_checked_idx + 1) == m_read_idx)
                return true;
            else if (buffer_[m_checked_idx + 1] == '\n')
            {
                buffer_[m_checked_idx++] = '\0';
                buffer_[m_checked_idx++] = '\0';
                return true;
            }
            return false;
        }
        else if (temp == '\n')
        {
            if (m_checked_idx > 1 && buffer_[m_checked_idx - 1] == '\r')
            {
                buffer_[m_checked_idx - 1] = '\0';
                buffer_[m_checked_idx++] = '\0';
                return true;
            }
            return false;
        }
    }
    return true;
}
