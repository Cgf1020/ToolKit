#include "httpconn.h"

#include <assert.h>
#include <string.h>
#include <iostream>


std::atomic<int> HttpConn::userCount = 0;

HttpConn::HttpConn()
{
    bzero(&buffer,sizeof(buffer));
}

HttpConn::~HttpConn()
{

}

void HttpConn::init(int fd, const sockaddr_in &addr)
{
    assert(fd > 0);

    addr_ = addr;
    fd_ = fd;

    isClose_ = false;
}

void HttpConn::Close()
{
    if(isClose_ == false){
        isClose_ = true;
        userCount--;
        close(fd_);
//        LOG_INFO("Client[%d](%s:%d) quit, UserCount:%d", fd_, GetIP(), GetPort(), (int)userCount);
    }
}

ssize_t HttpConn::read(int *saveErrno)
{
    ssize_t len = -1;
    do {
//        len = readBuff_.ReadFd(fd_, saveErrno);
        len = recv(fd_,buffer,sizeof(buffer),0);//接收数据
        if (len <= 0) {
            *saveErrno = errno;
            break;
        }

        m_read_idx += len;
    } while (1);

    std::cout << "saveErrno = " << *saveErrno << " len = " << len << "   HttpConn::read totll = " << m_read_idx << " buffer = " << buffer << std::endl;

    return len;
}

bool HttpConn::process()
{
    request_.Init();

    return request_.parse(buffer, m_read_idx);
}
































