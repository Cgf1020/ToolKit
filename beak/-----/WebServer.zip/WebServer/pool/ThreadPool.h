#ifndef THREADPOOL_H
#define THREADPOOL_H


/*
 * 线程池
*/
#include <assert.h>
#include <queue>
#include <functional>
#include <thread>
#include <mutex>
#include <memory>
#include <condition_variable>


class ThreadPool{

public:
    ThreadPool(int threadCount = 3)
        : threadCount_(threadCount)
        , pool_(std::make_shared<Pool>())
    {
        assert(threadCount > 0);

        //创建线程池
        for(int i =0; i < threadCount_; i++)
        {
            std::thread([&](){
                std::unique_lock<std::mutex> locker(pool_->mutex_);
                while(true)
                {
                    if(!pool_->tasks_.empty())
                    {
                        //执行任务
                        auto task = std::move(pool_->tasks_.front());
                        pool_->tasks_.pop();
                        task();
                    }
                    else if(pool_->isClosed)
                    {
                        //退出线程
                        break;
                    }
                    else
                    {
                        //阻塞睡眠
                        pool_->cond_.wait(locker);
                    }
                }
            }).detach();
        }
    }
    

    ThreadPool(ThreadPool&&) = default;


    ~ThreadPool(){

    }

public:
    /*添加任务
    */
    template <typename F>
    void AddTask(F&& task)
    {
        {
            std::lock_guard<std::mutex> locker(pool_->mutex_);
            pool_->tasks_.emplace(std::forward<F>(task));
        }
        pool_->cond_.notify_all();
    }



private:

    struct Pool{
        std::mutex mutex_;  //线程竞争之间的锁
        std::condition_variable cond_;      //条件变量
        bool isClosed{false};
        std::queue<std::function<void()>>  tasks_;  //任务队列, 函数指针
    };

    int threadCount_{3};    //线程数量

    std::shared_ptr<Pool> pool_;
};


#endif // THREADPOOL_H
