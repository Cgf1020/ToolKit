#include <iostream>

using namespace std;

#include "server/webserver.h"

int main()
{
    cout << "Hello World!" << endl;

    WebServer server;

    server.Start();

    return 0;
}
